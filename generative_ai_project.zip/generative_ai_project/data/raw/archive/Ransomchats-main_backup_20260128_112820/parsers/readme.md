Here are the parsers used to turn full html backups of ransomware discussions into JSON files. 
Feel free to use, then anonymise, and add your own copies of past ransomware conversations. 
