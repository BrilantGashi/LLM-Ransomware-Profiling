LockBit 3.0

You'll find here negotiations involving the LockBit 3.0 ransomware operation.
Most of them were disclosed by the gang itself. Some were provided by third parties. 
