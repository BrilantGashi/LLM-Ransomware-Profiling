Contributed by @g0njxa
